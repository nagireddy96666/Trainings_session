# import statement example
# to import standard module math

import math as m
import os
import datetime
import sys
import logging

#print(dir(math))
#print(dir(os))
print(os.getcwd())
print("The value of pi is", m.pi)

