import example

print(example.add(4,5.5))# Function call with filename.function(args)
