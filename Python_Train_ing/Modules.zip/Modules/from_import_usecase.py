# import only pi from math module

from math import pi,e
from math import *  # is equal to import math

print("The value of pi is", pi,e)
#print("The value of pi is", e)
